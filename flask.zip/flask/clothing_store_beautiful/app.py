from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import json, os

# ------------------- Налаштування Flask -------------------
app = Flask(__name__)
app.secret_key = "very_secret_key_12345"

BASE_DIR = os.path.dirname(__file__)
DATA_DIR = os.path.join(BASE_DIR, "data")
PRODUCTS_FILE = os.path.join(DATA_DIR, "products.json")
USERS_FILE = os.path.join(DATA_DIR, "users.json")
UPLOAD_FOLDER = os.path.join(BASE_DIR, "static", "images")
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif"}
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5 MB

# ------------------- Допоміжні функції -------------------
def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def load_json(path, default):
    if not os.path.exists(path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(default, f, ensure_ascii=False, indent=2)
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def save_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

# ------------------- Ініціалізація файлів -------------------
load_json(PRODUCTS_FILE, [])
load_json(USERS_FILE, [])

# ------------------- Контекст користувача -------------------
@app.context_processor
def inject_user():
    user = session.get("user")
    return dict(current_user=user)

# ------------------- Маршрути -------------------
@app.route("/")
def index():
    products = load_json(PRODUCTS_FILE, [])
    return render_template("index.html", products=products)

@app.route("/product/<int:product_id>")
def product(product_id):
    products = load_json(PRODUCTS_FILE, [])
    product = next((p for p in products if p["id"] == product_id), None)
    return render_template("product.html", product=product)

@app.route("/cart")
def cart():
    cart_items = session.get("cart", [])
    return render_template("cart.html", cart=cart_items)

@app.route("/add_to_cart/<int:product_id>")
def add_to_cart(product_id):
    products = load_json(PRODUCTS_FILE, [])
    product = next((p for p in products if p["id"] == product_id), None)
    if product:
        cart = session.get("cart", [])
        cart.append(product)
        session["cart"] = cart
        flash("Товар додано до кошика", "success")
    return redirect(url_for("cart"))

@app.route("/clear_cart")
def clear_cart():
    session["cart"] = []
    return redirect(url_for("cart"))

# ------------------- Аутентифікація -------------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if not username or not password:
            flash("Заповніть всі поля", "danger")
            return redirect(url_for("register"))
        users = load_json(USERS_FILE, [])
        if any(u["username"].lower() == username.lower() for u in users):
            flash("Користувач з таким ім'ям вже існує", "danger")
            return redirect(url_for("register"))
        hashed = generate_password_hash(password)
        is_admin = len(users) == 0  # перший користувач — адміністратор
        user = {"username": username, "password": hashed, "is_admin": is_admin}
        users.append(user)
        save_json(USERS_FILE, users)
        flash("Реєстрація успішна. Увійдіть у систему.", "success")
        return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        users = load_json(USERS_FILE, [])
        user = next((u for u in users if u["username"].lower() == username.lower()), None)
        if not user or not check_password_hash(user["password"], password):
            flash("Неправильні дані для входу", "danger")
            return redirect(url_for("login"))
        session["user"] = {"username": user["username"], "is_admin": user.get("is_admin", False)}
        flash(f"Вітаємо, {user['username']}!", "success")
        return redirect(url_for("index"))
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.pop("user", None)
    flash("Ви вийшли з облікового запису", "info")
    return redirect(url_for("index"))

# ------------------- Адмін-панель -------------------
def admin_required(func):
    from functools import wraps
    @wraps(func)
    def wrapper(*args, **kwargs):
        u = session.get("user")
        if not u or not u.get("is_admin"):
            flash("Доступ заборонено. Тільки для адміністратора.", "danger")
            return redirect(url_for("login"))
        return func(*args, **kwargs)
    return wrapper

@app.route("/admin")
@admin_required
def admin_panel():
    products = load_json(PRODUCTS_FILE, [])
    return render_template("admin.html", products=products)

@app.route("/admin/add", methods=["POST"])
@admin_required
def admin_add():
    name = request.form.get("name", "").strip()
    description = request.form.get("description", "").strip()
    price = request.form.get("price", "").strip()
    file = request.files.get("image")

    if not name or not price:
        flash("Назва та ціна є обов'язковими", "danger")
        return redirect(url_for("admin_panel"))


@app.route("/admin/delete/<int:product_id>", methods=["POST"])
@admin_required
def admin_delete(product_id):
    products = load_json(PRODUCTS_FILE, [])
    product = next((p for p in products if p["id"] == product_id), None)
    if product:
        # Видаляємо зображення, якщо воно не placeholder
        if product.get("image") and "/static/images/placeholder.png" not in product["image"]:
            img_path = os.path.join(BASE_DIR, product["image"].lstrip("/"))
            if os.path.exists(img_path):
                os.remove(img_path)
        # Видаляємо товар
        products = [p for p in products if p["id"] != product_id]
        save_json(PRODUCTS_FILE, products)
        flash(f"Товар '{product['name']}' видалено", "success")
    else:
        flash("Товар не знайдено", "danger")
    return redirect(url_for("admin_panel"))

    
    # Надійна обробка ціни
    try:
        clean_price = "".join(c for c in price if c.isdigit() or c in [",", "."])
        price_val = float(clean_price.replace(",", "."))
    except ValueError:
        flash("Ціна має бути числом", "danger")
        return redirect(url_for("admin_panel"))

    # Обробка файлу
    filename = ""
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        save_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        base, ext = os.path.splitext(filename)
        counter = 1
        while os.path.exists(save_path):
            filename = f"{base}_{counter}{ext}"
            save_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            counter += 1
        file.save(save_path)
        filename = "/static/images/" + filename

    # Додаємо товар
    products = load_json(PRODUCTS_FILE, [])
    new_id = max([p.get("id", 0) for p in products], default=0) + 1
    product = {
        "id": new_id,
        "name": name,
        "price": price_val,
        "image": filename or "/static/images/placeholder.png",
        "description": description
    }
    products.append(product)
    save_json(PRODUCTS_FILE, products)
    flash("Товар додано", "success")
    return redirect(url_for("admin_panel"))

# ------------------- Статичні зображення -------------------
@app.route('/static/images/<path:filename>')
def static_images(filename):
    return send_from_directory(os.path.join(BASE_DIR, 'static', 'images'), filename)

# ------------------- Запуск -------------------
if __name__ == "__main__":
    app.run(debug=True)
